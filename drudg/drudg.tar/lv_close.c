#include <stdio.h>
#include <string.h>
/*
000110 nrv New. Copied from vlogx.
*/
void lv_close(fp_out)

/* Input */
FILE *fp_out;

{
  fclose(fp_out);
}
