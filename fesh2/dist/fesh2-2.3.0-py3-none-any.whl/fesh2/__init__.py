# __init__.py
from fesh2._version import __version__

